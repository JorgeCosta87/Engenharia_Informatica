function y = fteste01(x)
y = abs(x)-exp(x);