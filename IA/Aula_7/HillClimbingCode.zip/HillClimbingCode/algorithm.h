//
int hill_climbing(int sol[], int *mat, int vert, int num_iter);
int simulated_annealing(int sol[], int *mat, int vert);
