//
int compute_fitness(int a[], int *mat, int vert);
