
int* init_data(char *nome, int *n, int *iter);

void create_initial_sol(int *sol, int v);

void write_sol(int *sol, int vert);

void replace_solution(int a[], int b[], int n);

void init_rand();

//

int random_l_h(int min, int max);

float rand_01();


